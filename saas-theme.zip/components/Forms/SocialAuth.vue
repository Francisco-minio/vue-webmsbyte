<template>
  <div class="socmed-side-login">
    <v-btn
      class="navi-btn"
      large
    >
      <i class="ion-logo-facebook" />
      Facebook
    </v-btn>
    <v-btn
      class="blue-btn"
      large
    >
      <i class="ion-logo-twitter " />
      Twitter
    </v-btn>
    <v-btn
      class="red-btn"
      large
    >
      <i class="ion-logo-google" />
      Google
    </v-btn>
  </div>
</template>

<style lang="scss" scoped>
@import './form-style.scss';
</style>
