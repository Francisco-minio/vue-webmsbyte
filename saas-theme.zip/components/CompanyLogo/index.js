export { default } from './CompanyLogo'
