export { default } from './Footer'
