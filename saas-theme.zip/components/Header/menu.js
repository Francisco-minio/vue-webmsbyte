const menu = ['feature', 'testimonials', 'pricing', 'faq']

export default menu
