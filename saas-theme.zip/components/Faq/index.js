export { default } from './Faq'
