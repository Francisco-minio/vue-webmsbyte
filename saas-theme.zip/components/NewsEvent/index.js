export { default } from './NewsEvent'
