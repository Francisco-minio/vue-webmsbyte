# `saas-theme`

> TODO: description

## Installation

```
lerna bootstrap
```

## Run Development

```
npm run dev
```

## Build

```
npm run build
```

## Run Production

```
npm start
```
