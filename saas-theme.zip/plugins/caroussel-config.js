import Vue from 'vue'
import Slick from 'vue-slick'

Vue.use(Slick)
