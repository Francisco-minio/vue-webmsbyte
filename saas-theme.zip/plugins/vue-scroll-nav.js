import Vue from 'vue'
import VueScrollactive from 'vue-scrollactive'

// use default options
Vue.use(VueScrollactive)
