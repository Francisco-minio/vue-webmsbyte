import Vue from 'vue'
import { Plugin } from 'vue-fragment'

Vue.use(Plugin)
