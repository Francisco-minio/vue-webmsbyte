import Vue from 'vue'
import options from 'vue-countup-directive/src'

Vue.directive('countUp', options)
