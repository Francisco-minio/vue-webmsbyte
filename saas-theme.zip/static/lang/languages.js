export default [{
        code: 'Es',
        iso: 'eS-Es',
        name: 'Español',
        file: 'id-Es.js',
        dir: 'ltr'

    },
    {
        code: 'en',
        iso: 'en-US',
        name: 'English',
        file: 'en-US.js',
        dir: 'ltr'



    }

]