const brand = {
    saas: {
        name: 'Msbyte',
        desc: 'Veluxi Saas - Vue Single Landing Page Template',
        prefix: 'veluxi',
        footerText: 'Msbyte 2022',
        logoText: 'Msbyte',
        projectName: 'Msbyte',
        url: 'veluxi.ux-maestro.com/saas',
        img: '/static/images/msbyte-logo.png',
        notifMsg: 'Donec sit amet nulla sed arcu pulvinar ultricies commodo id ligula.'
    }
}

export default brand